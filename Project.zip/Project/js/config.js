const CONFIG = {
    ADMIN_CREDENTIALS: {
        username: 'admin',
        password: '123456'
    },
    EMPLOYEE_CREDENTIALS: {
        username: 'employee', 
        password: '123456'
    },
    PATHS: {
        PRODUCT_IMAGES: 'images/products/',
        PRODUCT_VIDEOS: 'videos/products/',
        LOGO: 'images/logo.png'
    }
};

// ========== GLOBAL VARIABLES ==========
let adminCredentials = CONFIG.ADMIN_CREDENTIALS;
let employeeCredentials = CONFIG.EMPLOYEE_CREDENTIALS;
let currentAdminRole = 'admin';
let manualSales = [];
let cart = [];
let currentFilter = 'all';
let isAdminLoggedIn = false;
let nextProductId = 11;
let currentUser = null;
let users = [];
let expenses = [];
let currentSlideIndex = 0;
let sliderInterval;
let verificationCode = '';
let resetEmail = '';

// Slider indices for different categories
let sliderIndices = {
    all: 0,
    makeup: 0,
    hygiene: 0,
    skincare: 0,
    electronic: 0,
    other: 0
};