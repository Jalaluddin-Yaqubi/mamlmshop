const Cart = {
    add: function(productId) {
        const product = products.find(p => p.id === productId);
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        
        this.updateCount();
        Utils.showMessage(`${product.name} به سبد خرید اضافه شد`);
    },

    updateCount: function() {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        document.getElementById('cart-count').textContent = totalItems;
    },

    show: function() {
        const modal = document.getElementById('cart-modal');
        const cartItems = document.getElementById('cart-items');
        const cartTotal = document.getElementById('cart-total');
        
        cartItems.innerHTML = '';
        let total = 0;
        
        if (cart.length === 0) {
            cartItems.innerHTML = '<p class="text-center text-gray-500 py-8">سبد خرید شما خالی است</p>';
        } else {
            cart.forEach(item => {
                const displayPrice = currentUser ? parseInt(item.customerPrice) : parseInt(item.price);
                const itemTotal = displayPrice * item.quantity;
                total += itemTotal;
                
                const cartItem = document.createElement('div');
                cartItem.className = 'flex items-center justify-between py-4 border-b';
                cartItem.innerHTML = `
                    <div class="flex items-center">
                        <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${item.code}.jpg" alt="${item.name}" class="w-12 h-12 object-cover rounded mr-4" onerror="this.style.display='none';">
                        <div>
                            <h4 class="font-semibold">${item.name}</h4>
                            <p class="text-gray-600">${Utils.formatPrice(displayPrice)} افغانی ${currentUser ? '<span class="text-green-600 text-xs">(قیمت ویژه)</span>' : ''}</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <button onclick="Cart.changeQuantity(${item.id}, -1)" class="bg-gray-200 px-2 py-1 rounded">-</button>
                        <span class="mx-3">${item.quantity}</span>
                        <button onclick="Cart.changeQuantity(${item.id}, 1)" class="bg-gray-200 px-2 py-1 rounded">+</button>
                        <button onclick="Cart.remove(${item.id})" class="text-red-500 mr-4">🗑️</button>
                    </div>
                `;
                cartItems.appendChild(cartItem);
            });
        }
        
        cartTotal.textContent = `${Utils.formatPrice(total)} افغانی`;
        modal.classList.add('active');
    },

    close: function() {
        document.getElementById('cart-modal').classList.remove('active');
    },

    changeQuantity: function(productId, change) {
        const item = cart.find(item => item.id === productId);
        if (item) {
            item.quantity += change;
            if (item.quantity <= 0) {
                this.remove(productId);
            } else {
                this.updateCount();
                this.show(); // Refresh cart display
            }
        }
    },

    remove: function(productId) {
        cart = cart.filter(item => item.id !== productId);
        this.updateCount();
        this.show(); // Refresh cart display
    },

    completeOrder: function() {
        if (!currentUser) {
            Utils.showMessage('لطفاً ابتدا وارد حساب کاربری خود شوید', 'error');
            this.close();
            UserAuth.showModal();
            return;
        }
        
        if (cart.length === 0) {
            Utils.showMessage('سبد خرید شما خالی است', 'error');
            return;
        }
        
        // Create order message
        let message = `سلام، سفارش جدید از ${currentUser.name}:\n\n`;
        let total = 0;
        
        cart.forEach(item => {
            const displayPrice = currentUser ? parseInt(item.customerPrice) : parseInt(item.price);
            const itemTotal = displayPrice * item.quantity;
            total += itemTotal;
            message += `${item.name}\n`;
            message += `قیمت: ${Utils.formatPrice(displayPrice)} افغانی${currentUser ? ' (قیمت ویژه مشتری)' : ''}\n`;
            message += `تعداد: ${item.quantity}\n`;
            message += `جمع: ${Utils.formatPrice(itemTotal)} افغانی\n\n`;
        });
        
        message += `💰 مجموع کل: ${Utils.formatPrice(total)} افغانی\n\n`;
        message += `📞 شماره تماس: ${currentUser.phone}\n`;
        message += `📱 واتساپ: ${currentUser.whatsapp}`;
        
        // Send to WhatsApp
        const whatsappUrl = `https://wa.me/${currentUser.whatsapp.replace(/^0/, '93')}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
        
        // Clear cart
        cart = [];
        this.updateCount();
        this.close();
        
        Utils.showMessage('سفارش شما ارسال شد! به زودی با شما تماس خواهیم گرفت.');
    }
};

// ========== NEWSLETTER ==========
const Newsletter = {
    subscribe: function(event) {
        event.preventDefault();
        const email = document.getElementById('newsletter-email').value;
        Utils.showMessage(`با تشکر! ایمیل ${email} در خبرنامه ما ثبت شد.`);
        document.getElementById('newsletter-email').value = '';
    }
};