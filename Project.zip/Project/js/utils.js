const Utils = {
    formatPrice: function(price) {
        return parseInt(price).toLocaleString('fa-IR');
    },

    scrollToProducts: function() {
        document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
    },

    showModal: function(modalId) {
        document.getElementById(modalId).classList.add('active');
    },

    closeModal: function(modalId) {
        document.getElementById(modalId).classList.remove('active');
    },

    generateCode: function() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    },

    getCategoryName: function(category) {
        const categories = {
            'skincare': 'محصولات مراقبتی',
            'makeup': 'محصولات آرایشی',
            'hygiene': 'محصولات بهداشتی',
            'electronic': 'محصولات الکترونیکی',
            'other': 'سایر محصولات'
        };
        return categories[category] || category;
    },

    showMessage: function(text, type = 'success') {
        const message = document.createElement('div');
        const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
        message.className = `fixed top-20 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform`;
        message.textContent = text;
        document.body.appendChild(message);
        
        setTimeout(() => {
            message.classList.remove('translate-x-full');
        }, 100);
        
        setTimeout(() => {
            message.classList.add('translate-x-full');
            setTimeout(() => {
                document.body.removeChild(message);
            }, 300);
        }, 3000);
    }
};