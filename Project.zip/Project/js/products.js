let products = [
    // محصولات آرایشی
    {
        id: 1,
        code: 'P0001',
        name: "رژ لب مات طولانی مدت",
        price: "180",
        originalPrice: "220",
        costPrice: "120",
        customerPrice: "160",
        category: "makeup",
        image: "",
        rating: 4.6,
        stock: 30,
        sold: 8,
        description: "رژ لب با فرمول مات و ماندگاری بالا",
        ingredients: "رنگدانه‌های طبیعی، روغن جوجوبا",
        usage: "مستقیماً روی لب‌ها اعمال کنید"
    },
    {
        id: 2,
        code: 'P0002',
        name: "ریمل ضد آب",
        price: "210",
        originalPrice: "250",
        costPrice: "140",
        customerPrice: "190",
        category: "makeup",
        image: "",
        rating: 4.5,
        stock: 35,
        sold: 6,
        description: "ریمل ضد آب با برس منحصر به فرد",
        ingredients: "واکس طبیعی، ویتامین E",
        usage: "از ریشه مژه‌ها به سمت بالا حرکت دهید"
    },
    {
        id: 3,
        code: 'P0003',
        name: "پالت سایه چشم",
        price: "550",
        originalPrice: "650",
        costPrice: "350",
        customerPrice: "500",
        category: "makeup",
        image: "",
        rating: 4.6,
        stock: 22,
        sold: 7,
        description: "پالت 12 رنگ سایه چشم",
        ingredients: "رنگدانه‌های فشرده، میکا",
        usage: "با قلم مو روی پلک اعمال کنید"
    },
    // محصولات بهداشتی
    {
        id: 4,
        code: 'P0004',
        name: "شامپو تقویت کننده مو",
        price: "320",
        originalPrice: "380",
        costPrice: "220",
        customerPrice: "290",
        category: "hygiene",
        image: "",
        rating: 4.7,
        stock: 20,
        sold: 12,
        description: "شامپو تقویت کننده با عصاره گیاهی برای موهای ضعیف",
        ingredients: "کراتین، آرگان، روغن نارگیل",
        usage: "روی موهای مرطوب ماساژ دهید و آبکشی کنید"
    },
    {
        id: 5,
        code: 'P0005',
        name: "صابون طبیعی",
        price: "85",
        originalPrice: "100",
        costPrice: "50",
        customerPrice: "75",
        category: "hygiene",
        image: "",
        rating: 4.4,
        stock: 40,
        sold: 15,
        description: "صابون طبیعی با عصاره گیاهان",
        ingredients: "روغن زیتون، عسل، گلیسیرین",
        usage: "روی پوست مرطوب کف کنید"
    },
    // محصولات مراقبتی
    {
        id: 6,
        code: 'P0006',
        name: "کرم مرطوب کننده آلوئه ورا",
        price: "250",
        originalPrice: "300",
        costPrice: "180",
        customerPrice: "220",
        category: "skincare",
        image: "",
        rating: 4.8,
        stock: 25,
        sold: 15,
        description: "کرم مرطوب کننده طبیعی با عصاره آلوئه ورا برای تمام انواع پوست",
        ingredients: "آلوئه ورا، گلیسیرین، ویتامین E",
        usage: "روزانه صبح و شب روی پوست تمیز بمالید"
    },
    {
        id: 7,
        code: 'P0007',
        name: "سرم ویتامین C",
        price: "450",
        originalPrice: "520",
        costPrice: "300",
        customerPrice: "400",
        category: "skincare",
        image: "",
        rating: 4.9,
        stock: 15,
        sold: 20,
        description: "سرم روشن کننده و ضد پیری با ویتامین C",
        ingredients: "ویتامین C، هیالورونیک اسید",
        usage: "شب‌ها روی پوست تمیز اعمال کنید"
    },
    {
        id: 8,
        code: 'P0008',
        name: "کرم ضد آفتاب SPF50",
        price: "380",
        originalPrice: "430",
        costPrice: "250",
        customerPrice: "340",
        category: "skincare",
        image: "",
        rating: 4.8,
        stock: 18,
        sold: 10,
        description: "کرم ضد آفتاب با حفاظت بالا",
        ingredients: "اکسید روی، تیتانیوم دی اکساید",
        usage: "30 دقیقه قبل از خروج اعمال کنید"
    },
    // محصولات الکترونیکی
    {
        id: 9,
        code: 'P0009',
        name: "مسواک برقی",
        price: "1200",
        originalPrice: "1500",
        costPrice: "800",
        customerPrice: "1100",
        category: "electronic",
        image: "",
        rating: 4.7,
        stock: 8,
        sold: 4,
        description: "مسواک برقی با تکنولوژی پیشرفته",
        ingredients: "موتور سونیک، سر برس نرم",
        usage: "2 دقیقه صبح و شب استفاده کنید"
    },
    {
        id: 10,
        code: 'P0010',
        name: "دستگاه بخور سرد",
        price: "850",
        originalPrice: "1000",
        costPrice: "600",
        customerPrice: "780",
        category: "electronic",
        image: "",
        rating: 4.5,
        stock: 12,
        sold: 3,
        description: "دستگاه بخور سرد برای مراقبت از پوست",
        ingredients: "فن التراسونیک، مخزن آب",
        usage: "آب تمیز اضافه کرده و روشن کنید"
    }
];

// ========== PRODUCT MANAGEMENT ==========
const ProductManager = {
    render: function() {
        this.renderByCategory('all');
        this.renderByCategory('makeup');
        this.renderByCategory('hygiene');
        this.renderByCategory('skincare');
        this.renderByCategory('electronic');
        this.renderByCategory('other');
    },

    renderByCategory: function(category) {
        const trackId = category === 'all' ? 'slider-track-all' : `slider-track-${category}`;
        const track = document.getElementById(trackId);
        if (!track) return;
        
        track.innerHTML = '';
        
        const productsToRender = category === 'all' ? products : products.filter(p => p.category === category);
        
        if (productsToRender.length === 0) {
            track.innerHTML = '<div class="text-center text-gray-500 py-8 w-full">محصولی در این دسته یافت نشد</div>';
            return;
        }

        productsToRender.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'slider-item';
            productCard.innerHTML = `
                <div class="product-card bg-gradient-to-br from-blue-100 via-purple-50 to-orange-100 rounded-xl shadow-md overflow-hidden cursor-pointer h-full border border-blue-200">
                    <div class="p-6 text-center">
                        <div class="mb-4 bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto shadow-sm overflow-hidden">
                            <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${product.code}.jpg" alt="${product.name}" class="w-full h-full object-cover rounded-full" onerror="this.style.display='none'; this.parentElement.innerHTML='<span class=\\'text-gray-400 text-sm\\'>تصویر</span>';">
                        </div>
                        <h4 class="text-lg font-semibold text-gray-800 mb-4">${product.name}</h4>
                        <button onclick="ProductModal.show(${product.id}); event.preventDefault(); event.stopPropagation();" class="bg-gradient-to-r from-blue-600 to-orange-500 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-orange-600 transition-all shadow-md">
                            ادامه
                        </button>
                    </div>
                </div>
            `;
            track.appendChild(productCard);
        });
    },

    search: function(event) {
        const searchTerm = event.target.value.toLowerCase();
        const filteredProducts = products.filter(product => 
            product.name.toLowerCase().includes(searchTerm)
        );
        
        // Show filtered results in all products section
        const track = document.getElementById('slider-track-all');
        track.innerHTML = '';
        
        if (filteredProducts.length === 0) {
            track.innerHTML = '<div class="text-center text-gray-500 py-8 w-full">محصولی یافت نشد</div>';
            return;
        }

        filteredProducts.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'slider-item';
            productCard.innerHTML = `
                <div class="product-card bg-gradient-to-br from-blue-100 via-purple-50 to-orange-100 rounded-xl shadow-md overflow-hidden cursor-pointer h-full border border-blue-200">
                    <div class="p-6 text-center">
                        <div class="mb-4 bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto shadow-sm overflow-hidden">
                            <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${product.code}.jpg" alt="${product.name}" class="w-full h-full object-cover rounded-full" onerror="this.style.display='none'; this.parentElement.innerHTML='<span class=\\'text-gray-400 text-sm\\'>تصویر</span>';">
                        </div>
                        <h4 class="text-lg font-semibold text-gray-800 mb-4">${product.name}</h4>
                        <button onclick="ProductModal.show(${product.id}); event.preventDefault(); event.stopPropagation();" class="bg-gradient-to-r from-blue-600 to-orange-500 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-orange-600 transition-all shadow-md">
                            ادامه
                        </button>
                    </div>
                </div>
            `;
            track.appendChild(productCard);
        });
    }
};

// ========== PRODUCT SLIDER ==========
const ProductSlider = {
    init: function() {
        // Initialize all sliders
        Object.keys(sliderIndices).forEach(category => {
            sliderIndices[category] = 0;
        });
    },

    next: function(category) {
        const trackId = category === 'all' ? 'slider-track-all' : `slider-track-${category}`;
        const track = document.getElementById(trackId);
        if (!track) return;
        
        const items = track.children;
        const itemsPerView = window.innerWidth < 768 ? 1 : window.innerWidth < 1024 ? 2 : 3;
        const maxIndex = Math.max(0, items.length - itemsPerView);
        
        sliderIndices[category] = Math.min(sliderIndices[category] + 1, maxIndex);
        this.updatePosition(category);
    },

    prev: function(category) {
        sliderIndices[category] = Math.max(sliderIndices[category] - 1, 0);
        this.updatePosition(category);
    },

    updatePosition: function(category) {
        const trackId = category === 'all' ? 'slider-track-all' : `slider-track-${category}`;
        const track = document.getElementById(trackId);
        if (!track) return;
        
        const itemWidth = window.innerWidth < 768 ? 100 : window.innerWidth < 1024 ? 50 : 33.333;
        track.style.transform = `translateX(-${sliderIndices[category] * itemWidth}%)`;
    },

    reset: function() {
        Object.keys(sliderIndices).forEach(category => {
            sliderIndices[category] = 0;
            this.updatePosition(category);
        });
    }
};

// ========== PRODUCT MODAL ==========
const ProductModal = {
    show: function(productId) {
        const product = products.find(p => p.id === productId);
        const modal = document.getElementById('product-modal');
        const title = document.getElementById('product-modal-title');
        const content = document.getElementById('product-modal-content');
        
        title.textContent = product.name;
        content.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="text-center">
                    <div class="mb-4">
                        <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${product.code}.jpg" alt="${product.name}" class="w-32 h-32 object-cover rounded-lg mx-auto mb-4" onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\\'w-32 h-32 bg-gray-200 rounded-lg mx-auto mb-4 flex items-center justify-center\\'>تصویر محصول</div>';">
                        ${product.video ? `<video src="${CONFIG.PATHS.PRODUCT_VIDEOS}${product.code}.mp4" class="w-full max-w-sm mx-auto rounded-lg" controls></video>` : ''}
                    </div>
                </div>
                <div>
                    <h3 class="text-2xl font-bold mb-4">${product.name}</h3>
                    <div class="mb-4">
                        <span class="text-sm font-semibold text-gray-600">کد محصول: </span>
                        <span class="text-sm text-gray-800">${product.code}</span>
                    </div>
                    <div class="flex items-center mb-4">
                        <div class="flex text-yellow-400 text-lg">
                            ${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}
                        </div>
                        <span class="text-gray-600 mr-2">(${product.rating})</span>
                    </div>
                    <div class="mb-4">
                        <span class="text-sm font-semibold text-gray-600">موجودی: </span>
                        <span class="text-sm ${product.stock > 10 ? 'text-green-600' : 'text-red-600'}">${product.stock} عدد</span>
                    </div>
                    <div class="mb-4">
                        <span class="text-sm font-semibold text-gray-600">تعداد فروخته شده: </span>
                        <span class="text-sm text-gray-800">${product.sold} عدد</span>
                    </div>
                    <div class="mb-6">
                        ${currentUser ? `
                            <div class="mb-2">
                                <span class="text-3xl font-bold text-green-600">${Utils.formatPrice(product.customerPrice)} افغانی</span>
                                <span class="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full mr-2">قیمت ویژه مشتریان</span>
                            </div>
                            <div class="text-sm text-gray-500">
                                <span class="line-through">قیمت عادی: ${Utils.formatPrice(product.price)} افغانی</span>
                                <span class="text-red-500 font-semibold mr-2">تخفیف: ${Utils.formatPrice(parseInt(product.price) - parseInt(product.customerPrice))} افغانی</span>
                            </div>
                        ` : `
                            <span class="text-3xl font-bold text-blue-600">${Utils.formatPrice(product.price)} افغانی</span>
                            <div class="text-sm text-gray-500 mt-2">
                                <span>💡 با ثبت نام ${Utils.formatPrice(parseInt(product.price) - parseInt(product.customerPrice))} افغانی تخفیف بگیرید!</span>
                            </div>
                        `}
                    </div>
                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">توضیحات:</h4>
                        <p class="text-gray-600 text-sm">${product.description}</p>
                    </div>
                    <div class="mb-4">
                        <h4 class="font-semibold mb-2">ترکیبات:</h4>
                        <p class="text-gray-600 text-sm">${product.ingredients}</p>
                    </div>
                    <div class="mb-6">
                        <h4 class="font-semibold mb-2">نحوه استفاده:</h4>
                        <p class="text-gray-600 text-sm">${product.usage}</p>
                    </div>
                    <div class="mb-6">
                        <h4 class="font-semibold mb-2">دسته‌بندی:</h4>
                        <span class="bg-gray-100 px-3 py-1 rounded-full text-sm">${Utils.getCategoryName(product.category)}</span>
                    </div>
                    <button onclick="Cart.add(${product.id}); ProductModal.close();" class="w-full bg-gradient-to-r from-blue-600 to-orange-500 text-white py-3 rounded-lg hover:from-blue-700 hover:to-orange-600 transition-all text-lg">
                        افزودن به سبد خرید
                    </button>
                </div>
            </div>
        `;
        modal.classList.add('active');
    },

    close: function() {
        document.getElementById('product-modal').classList.remove('active');
    }
};