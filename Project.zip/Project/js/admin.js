const AdminPanel = {
    show: function() {
        document.getElementById('main-site').classList.add('hidden');
        document.getElementById('admin-panel').classList.add('active');
        this.setupRoleBasedAccess();
        AdminProductManager.render();
        InventoryManager.render();
        SalesManager.render();
        CustomerManager.render();
        ExpenseManager.render();
        FinancialManager.updateStats();
    },

    setupRoleBasedAccess: function() {
        const roleDisplay = document.getElementById('admin-role-display');
        const financialNav = document.getElementById('financial-nav');
        const settingsNav = document.getElementById('settings-nav');
        const expenseActionsHeader = document.getElementById('expense-actions-header');
        
        if (currentAdminRole === 'admin') {
            roleDisplay.textContent = 'مدیر کل';
            financialNav.style.display = 'block';
            settingsNav.style.display = 'block';
            if (expenseActionsHeader) expenseActionsHeader.style.display = 'table-cell';
        } else {
            roleDisplay.textContent = 'کارمند';
            financialNav.style.display = 'none';
            settingsNav.style.display = 'none';
            if (expenseActionsHeader) expenseActionsHeader.style.display = 'none';
        }
    },

    showMainSite: function() {
        document.getElementById('admin-panel').classList.remove('active');
        document.getElementById('main-site').classList.remove('hidden');
    },

    showSection: function(section) {
        // Check permissions for employee
        if (currentAdminRole === 'employee' && (section === 'financial' || section === 'settings')) {
            Utils.showMessage('شما اجازه دسترسی به این بخش را ندارید', 'error');
            return;
        }

        // Hide all sections
        document.querySelectorAll('.admin-section').forEach(sec => {
            sec.classList.add('hidden');
        });
        
        // Show selected section
        document.getElementById(`admin-${section}`).classList.remove('hidden');
        
        // Update navigation
        document.querySelectorAll('.admin-nav-item').forEach(nav => {
            nav.classList.remove('border-r-4', 'border-blue-500', 'bg-gray-50');
        });
        event.target.classList.add('border-r-4', 'border-blue-500', 'bg-gray-50');

        // Render section-specific data
        if (section === 'sales') {
            SalesManager.render();
        } else if (section === 'financial') {
            FinancialManager.updateStats();
        } else if (section === 'settings') {
            CustomerManager.render();
        }
    }
};

// ========== INVENTORY MANAGEMENT ==========
const InventoryManager = {
    render: function() {
        const tbody = document.getElementById('inventory-table');
        tbody.innerHTML = '';
        
        let totalProducts = products.length;
        let inStock = 0;
        let lowStock = 0;
        let totalValue = 0;
        
        products.forEach(product => {
            const profit = parseInt(product.price) - parseInt(product.costPrice);
            const totalProfit = profit * product.sold;
            
            if (product.stock > 10) {
                inStock++;
            } else {
                lowStock++;
            }
            
            totalValue += parseInt(product.costPrice) * product.stock;
            
            const row = document.createElement('tr');
            const stockClass = product.stock > 10 ? 'bg-green-50' : 'bg-red-50';
            row.className = stockClass;
            
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.code}</td>
                <td class="px-4 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${product.code}.jpg" alt="${product.name}" class="w-8 h-8 object-cover rounded mr-3" onerror="this.style.display='none';">
                        <span class="text-sm font-medium text-gray-900">${product.name}</span>
                    </div>
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="${product.stock > 10 ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}">${product.stock} عدد</span>
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${product.sold} عدد</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${Utils.formatPrice(product.costPrice)} افغانی</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${Utils.formatPrice(product.price)} افغانی</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium ${profit > 0 ? 'text-green-600' : 'text-red-600'}">
                    ${Utils.formatPrice(profit)} افغانی
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium ${totalProfit > 0 ? 'text-green-600' : 'text-red-600'}">
                    ${Utils.formatPrice(totalProfit)} افغانی
                </td>
            `;
            tbody.appendChild(row);
        });

        // Update stats
        document.getElementById('total-inventory').textContent = totalProducts;
        document.getElementById('in-stock').textContent = inStock;
        document.getElementById('low-stock').textContent = lowStock;
        document.getElementById('inventory-value').textContent = `${Utils.formatPrice(totalValue)} افغانی`;
    }
};

// ========== SALES MANAGEMENT ==========
const SalesManager = {
    render: function() {
        this.populateProductSelect();
        this.updateSalesStats();
        this.renderSalesHistory();
        this.renderBestSelling();
    },

    populateProductSelect: function() {
        const select = document.getElementById('manual-sale-product');
        select.innerHTML = '<option value="">انتخاب محصول</option>';
        
        products.forEach(product => {
            const option = document.createElement('option');
            option.value = product.id;
            option.textContent = `${product.code} - ${product.name}`;
            select.appendChild(option);
        });
    },

    addManualSale: function(event) {
        event.preventDefault();
        const productId = parseInt(document.getElementById('manual-sale-product').value);
        const quantity = parseInt(document.getElementById('manual-sale-quantity').value);
        
        const product = products.find(p => p.id === productId);
        if (!product) {
            Utils.showMessage('محصول انتخاب شده یافت نشد', 'error');
            return;
        }

        if (product.stock < quantity) {
            Utils.showMessage('موجودی کافی نیست', 'error');
            return;
        }

        // Update product stock and sold count
        product.stock -= quantity;
        product.sold += quantity;

        // Add to manual sales record
        const sale = {
            id: manualSales.length + 1,
            productId: productId,
            productName: product.name,
            productCode: product.code,
            quantity: quantity,
            unitPrice: parseInt(product.price),
            totalAmount: parseInt(product.price) * quantity,
            date: new Date().toLocaleDateString('en-US'),
            timestamp: new Date().getTime()
        };

        manualSales.push(sale);

        // Reset form
        document.getElementById('manual-sale-product').value = '';
        document.getElementById('manual-sale-quantity').value = '';

        // Update displays
        this.updateSalesStats();
        this.renderSalesHistory();
        this.renderBestSelling();
        InventoryManager.render();
        FinancialManager.updateStats();

        Utils.showMessage(`فروش ${quantity} عدد ${product.name} ثبت شد`);
    },

    updateSalesStats: function() {
        const today = new Date().toLocaleDateString('en-US');
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).getTime();
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        let salesToday = 0;
        let salesWeekly = 0;
        let salesMonthly = 0;
        let salesTotal = 0;

        manualSales.forEach(sale => {
            const saleDate = new Date(sale.timestamp);
            
            // Today's sales
            if (sale.date === today) {
                salesToday += sale.totalAmount;
            }
            
            // Weekly sales
            if (sale.timestamp >= oneWeekAgo) {
                salesWeekly += sale.totalAmount;
            }
            
            // Monthly sales
            if (saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear) {
                salesMonthly += sale.totalAmount;
            }
            
            // Total sales
            salesTotal += sale.totalAmount;
        });

        document.getElementById('sales-today').textContent = `${Utils.formatPrice(salesToday)} افغانی`;
        document.getElementById('sales-weekly').textContent = `${Utils.formatPrice(salesWeekly)} افغانی`;
        document.getElementById('sales-monthly').textContent = `${Utils.formatPrice(salesMonthly)} افغانی`;
        document.getElementById('sales-total').textContent = `${Utils.formatPrice(salesTotal)} افغانی`;
    },

    renderSalesHistory: function() {
        const tbody = document.getElementById('sales-history-table');
        tbody.innerHTML = '';

        if (manualSales.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-gray-500">هنوز فروشی ثبت نشده است</td></tr>';
            return;
        }

        manualSales.forEach((sale, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${index + 1}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${sale.productCode}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${sale.productName}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${sale.quantity} عدد</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${Utils.formatPrice(sale.unitPrice)} افغانی</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-green-600 font-medium">${Utils.formatPrice(sale.totalAmount)} افغانی</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${sale.date}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                    <div class="flex space-x-2 space-x-reverse">
                        <button onclick="SalesManager.editSale(${sale.id})" class="text-blue-600 hover:text-blue-900">ویرایش</button>
                        <button onclick="SalesManager.deleteSale(${sale.id})" class="text-red-600 hover:text-red-900">حذف</button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    },

    editSale: function(saleId) {
        const sale = manualSales.find(s => s.id === saleId);
        if (!sale) return;

        // Fill form with sale data
        document.getElementById('manual-sale-product').value = sale.productId;
        document.getElementById('manual-sale-quantity').value = sale.quantity;

        // Change form to edit mode
        const form = document.querySelector('#admin-sales form');
        form.onsubmit = (event) => this.updateSale(event, saleId);
        
        // Change button text
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'بروزرسانی فروش';
        submitBtn.className = 'bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 w-full';
    },

    updateSale: function(event, saleId) {
        event.preventDefault();
        
        const sale = manualSales.find(s => s.id === saleId);
        if (!sale) return;

        const newProductId = parseInt(document.getElementById('manual-sale-product').value);
        const newQuantity = parseInt(document.getElementById('manual-sale-quantity').value);
        const newProduct = products.find(p => p.id === newProductId);
        
        if (!newProduct) {
            Utils.showMessage('محصول انتخاب شده یافت نشد', 'error');
            return;
        }

        // Restore old product stock
        const oldProduct = products.find(p => p.id === sale.productId);
        if (oldProduct) {
            oldProduct.stock += sale.quantity;
            oldProduct.sold -= sale.quantity;
        }

        // Check new product stock
        if (newProduct.stock < newQuantity) {
            Utils.showMessage('موجودی کافی نیست', 'error');
            // Restore old sale
            if (oldProduct) {
                oldProduct.stock -= sale.quantity;
                oldProduct.sold += sale.quantity;
            }
            return;
        }

        // Update new product stock
        newProduct.stock -= newQuantity;
        newProduct.sold += newQuantity;

        // Update sale record
        sale.productId = newProductId;
        sale.productName = newProduct.name;
        sale.productCode = newProduct.code;
        sale.quantity = newQuantity;
        sale.unitPrice = parseInt(newProduct.price);
        sale.totalAmount = parseInt(newProduct.price) * newQuantity;

        // Reset form to add mode
        const form = document.querySelector('#admin-sales form');
        form.onsubmit = (event) => this.addManualSale(event);
        
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'ثبت فروش';
        submitBtn.className = 'bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600 w-full';

        // Reset form
        document.getElementById('manual-sale-product').value = '';
        document.getElementById('manual-sale-quantity').value = '';

        // Update displays
        this.updateSalesStats();
        this.renderSalesHistory();
        this.renderBestSelling();
        InventoryManager.render();
        FinancialManager.updateStats();

        Utils.showMessage('فروش با موفقیت بروزرسانی شد');
    },

    deleteSale: function(saleId) {
        if (confirm('آیا مطمئن هستید که می‌خواهید این فروش را حذف کنید؟')) {
            const sale = manualSales.find(s => s.id === saleId);
            if (sale) {
                // Restore product stock
                const product = products.find(p => p.id === sale.productId);
                if (product) {
                    product.stock += sale.quantity;
                    product.sold -= sale.quantity;
                }

                // Remove sale from records
                manualSales = manualSales.filter(s => s.id !== saleId);

                // Update displays
                this.updateSalesStats();
                this.renderSalesHistory();
                this.renderBestSelling();
                InventoryManager.render();
                FinancialManager.updateStats();

                Utils.showMessage('فروش حذف شد');
            }
        }
    },

    printSales: function(period) {
        const printWindow = window.open('', '_blank');
        const currentDate = new Date().toLocaleDateString('en-US');
        
        let filteredSales = [];
        let periodTitle = '';
        
        const today = new Date().toLocaleDateString('en-US');
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).getTime();
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        switch(period) {
            case 'today':
                filteredSales = manualSales.filter(sale => sale.date === today);
                periodTitle = 'فروش امروز';
                break;
            case 'weekly':
                filteredSales = manualSales.filter(sale => sale.timestamp >= oneWeekAgo);
                periodTitle = 'فروش هفتگی';
                break;
            case 'monthly':
                filteredSales = manualSales.filter(sale => {
                    const saleDate = new Date(sale.timestamp);
                    return saleDate.getMonth() === currentMonth && saleDate.getFullYear() === currentYear;
                });
                periodTitle = 'فروش ماهانه';
                break;
            case 'all':
                filteredSales = manualSales;
                periodTitle = 'تمام فروشات';
                break;
        }

        let totalSales = 0;
        filteredSales.forEach(sale => {
            totalSales += sale.totalAmount;
        });

        const printContent = `
            <!DOCTYPE html>
            <html dir="rtl" lang="fa">
            <head>
                <meta charset="UTF-8">
                <title>گزارش ${periodTitle} - فروشگاه مصطفی ادیب</title>
                <style>
                    @page { size: A4 portrait; margin: 2cm; }
                    body { font-family: 'B Mitra', Arial, sans-serif; font-size: 12px; line-height: 1.4; }
                    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
                    .header h1 { margin: 0; font-size: 18px; }
                    .header p { margin: 5px 0; color: #666; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
                    th { background-color: #f5f5f5; font-weight: bold; }
                    .total-row { background-color: #e8f5e8; font-weight: bold; }
                    .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>گزارش ${periodTitle}</h1>
                    <p>فروشگاه مصطفی ادیب</p>
                    <p>تاریخ چاپ: ${currentDate}</p>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>شماره</th>
                            <th>کد محصول</th>
                            <th>نام محصول</th>
                            <th>تعداد</th>
                            <th>قیمت واحد (افغانی)</th>
                            <th>مجموع (افغانی)</th>
                            <th>تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredSales.map((sale, index) => `
                            <tr>
                                <td>${index + 1}</td>
                                <td>${sale.productCode}</td>
                                <td>${sale.productName}</td>
                                <td>${sale.quantity}</td>
                                <td>${Utils.formatPrice(sale.unitPrice)}</td>
                                <td>${Utils.formatPrice(sale.totalAmount)}</td>
                                <td>${sale.date}</td>
                            </tr>
                        `).join('')}
                        <tr class="total-row">
                            <td colspan="5">مجموع کل فروشات</td>
                            <td>${Utils.formatPrice(totalSales)}</td>
                            <td>-</td>
                        </tr>
                    </tbody>
                </table>
                
                <div style="margin-top: 50px; display: flex; justify-content: space-between; align-items: flex-end;">
                    <div style="text-align: right; width: 45%;">
                        <div style="border-top: 1px solid #333; padding-top: 10px; margin-top: 40px;">
                            <p style="margin: 0; font-weight: bold;">امضای مدیر فروشات</p>
                        </div>
                    </div>
                    <div style="text-align: left; width: 45%;">
                        <div style="border-top: 1px solid #333; padding-top: 10px; margin-top: 40px;">
                            <p style="margin: 0; font-weight: bold;">امضای مدیر مالی</p>
                        </div>
                    </div>
                </div>
                
                <div class="footer">
                    <p>این گزارش توسط سیستم مدیریت فروشگاه مصطفی ادیب تولید شده است</p>
                    <p>تلفن: 93792149150 | ایمیل: jalaluddinyaqubi@gmail.com</p>
                </div>
            </body>
            </html>
        `;

        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
    },

    renderBestSelling: function() {
        const tbody = document.getElementById('best-selling-table');
        tbody.innerHTML = '';

        // Calculate best selling products
        const productSales = {};
        
        products.forEach(product => {
            if (product.sold > 0) {
                productSales[product.id] = {
                    code: product.code,
                    name: product.name,
                    sold: product.sold,
                    totalRevenue: product.sold * parseInt(product.price)
                };
            }
        });

        // Sort by quantity sold
        const sortedProducts = Object.values(productSales).sort((a, b) => b.sold - a.sold);

        if (sortedProducts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-gray-500">هنوز فروشی ثبت نشده است</td></tr>';
            return;
        }

        sortedProducts.forEach(product => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${product.code}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.name}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${product.sold} عدد</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-green-600 font-medium">${Utils.formatPrice(product.totalRevenue)} افغانی</td>
            `;
            tbody.appendChild(row);
        });
    }
};

// ========== FINANCIAL MANAGEMENT ==========
const FinancialManager = {
    updateStats: function() {
        if (currentAdminRole !== 'admin') return;

        let totalRevenue = 0;
        let totalExpenses = 0;

        // Calculate revenue from sales
        manualSales.forEach(sale => {
            totalRevenue += sale.totalAmount;
        });

        // Calculate total expenses
        expenses.forEach(expense => {
            totalExpenses += expense.amount;
        });

        const netProfit = totalRevenue - totalExpenses;
        const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : 0;

        document.getElementById('total-revenue').textContent = `${Utils.formatPrice(totalRevenue)} افغانی`;
        document.getElementById('total-expenses').textContent = `${Utils.formatPrice(totalExpenses)} افغانی`;
        document.getElementById('net-profit').textContent = `${Utils.formatPrice(netProfit)} افغانی`;
        document.getElementById('payable-amount').textContent = `${Utils.formatPrice(Math.max(0, netProfit))} افغانی`;
        document.getElementById('customer-debt').textContent = '0 افغانی'; // Placeholder

        // Update category profits
        this.updateCategoryProfits();
    },

    updateCategoryProfits: function() {
        const categoryProfits = {
            skincare: 0,
            makeup: 0,
            hygiene: 0,
            electronic: 0
        };

        products.forEach(product => {
            if (product.sold > 0) {
                const profit = (parseInt(product.price) - parseInt(product.costPrice)) * product.sold;
                if (categoryProfits.hasOwnProperty(product.category)) {
                    categoryProfits[product.category] += profit;
                }
            }
        });

        document.getElementById('skincare-profit').textContent = `${Utils.formatPrice(categoryProfits.skincare)} افغانی`;
        document.getElementById('makeup-profit').textContent = `${Utils.formatPrice(categoryProfits.makeup)} افغانی`;
        document.getElementById('hygiene-profit').textContent = `${Utils.formatPrice(categoryProfits.hygiene)} افغانی`;
        document.getElementById('electronic-profit').textContent = `${Utils.formatPrice(categoryProfits.electronic)} افغانی`;
    }
};

// ========== CUSTOMER MANAGEMENT ==========
const CustomerManager = {
    render: function() {
        if (currentAdminRole !== 'admin') return;
        
        this.renderPendingUsers();
        this.renderAllCustomers();
    },

    renderPendingUsers: function() {
        const container = document.getElementById('pending-users');
        container.innerHTML = '';

        const pendingUsers = users.filter(user => !user.approved);
        
        if (pendingUsers.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-center py-4">درخواست جدیدی وجود ندارد</p>';
            return;
        }

        pendingUsers.forEach(user => {
            const userCard = document.createElement('div');
            userCard.className = 'bg-yellow-50 border border-yellow-200 rounded-lg p-4';
            userCard.innerHTML = `
                <div class="flex justify-between items-center">
                    <div>
                        <h5 class="font-semibold">${user.name}</h5>
                        <p class="text-sm text-gray-600">${user.email}</p>
                        <p class="text-sm text-gray-600">تلفن: ${user.phone}</p>
                    </div>
                    <div class="flex space-x-2 space-x-reverse">
                        <button onclick="CustomerManager.approveUser(${user.id})" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">
                            تایید
                        </button>
                        <button onclick="CustomerManager.rejectUser(${user.id})" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600">
                            رد
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(userCard);
        });
    },

    renderAllCustomers: function() {
        const tbody = document.getElementById('all-customers-table');
        tbody.innerHTML = '';

        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${user.name}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${user.email}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${user.phone}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${user.registrationDate}</td>
                <td class="px-4 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${user.approved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
                        ${user.approved ? 'تایید شده' : 'در انتظار تایید'}
                    </span>
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                    ${user.approved ? 
                        `<button onclick="CustomerManager.suspendUser(${user.id})" class="text-red-600 hover:text-red-900">تعلیق</button>` :
                        `<button onclick="CustomerManager.approveUser(${user.id})" class="text-green-600 hover:text-green-900">تایید</button>`
                    }
                </td>
            `;
            tbody.appendChild(row);
        });
    },

    approveUser: function(userId) {
        const user = users.find(u => u.id === userId);
        if (user) {
            user.approved = true;
            Utils.showMessage(`کاربر ${user.name} تایید شد`);
            this.render();
        }
    },

    rejectUser: function(userId) {
        if (confirm('آیا مطمئن هستید که می‌خواهید این درخواست را رد کنید؟')) {
            users = users.filter(u => u.id !== userId);
            Utils.showMessage('درخواست رد شد');
            this.render();
        }
    },

    suspendUser: function(userId) {
        if (confirm('آیا مطمئن هستید که می‌خواهید این کاربر را تعلیق کنید؟')) {
            const user = users.find(u => u.id === userId);
            if (user) {
                user.approved = false;
                Utils.showMessage(`کاربر ${user.name} تعلیق شد`);
                this.render();
            }
        }
    }
};

// ========== ADMIN PRODUCT MANAGEMENT ==========
const AdminProductManager = {
    showAddForm: function() {
        // Generate next product code automatically
        const maxId = Math.max(...products.map(p => parseInt(p.code.replace('P', ''))), 0);
        const nextCode = `P${String(maxId + 1).padStart(4, '0')}`;
        document.getElementById('product-code').value = nextCode;
        document.getElementById('add-product-form').classList.remove('hidden');
    },

    hideAddForm: function() {
        document.getElementById('add-product-form').classList.add('hidden');
        document.getElementById('add-product-form').querySelector('form').reset();
    },

    add: function(event) {
        event.preventDefault();
        
        // Handle image upload
        const imageFile = document.getElementById('product-image').files[0];
        const videoFile = document.getElementById('product-video').files[0];
        
        let imageUrl = '';
        let videoUrl = '';
        
        if (imageFile) {
            imageUrl = URL.createObjectURL(imageFile);
        }
        
        if (videoFile) {
            videoUrl = URL.createObjectURL(videoFile);
        }
        
        const newProduct = {
            id: nextProductId++,
            code: document.getElementById('product-code').value,
            name: document.getElementById('product-name').value,
            price: document.getElementById('product-price').value,
            originalPrice: document.getElementById('product-original-price').value,
            costPrice: document.getElementById('product-cost-price').value,
            customerPrice: document.getElementById('product-customer-price').value,
            stock: parseInt(document.getElementById('product-stock').value),
            sold: 0,
            category: document.getElementById('product-category').value,
            image: imageUrl,
            video: videoUrl,
            rating: parseFloat(document.getElementById('product-rating').value),
            description: document.getElementById('product-description').value,
            ingredients: document.getElementById('product-ingredients').value,
            usage: document.getElementById('product-usage').value
        };
        
        products.push(newProduct);
        this.render();
        ProductManager.render(); // Update main site
        InventoryManager.render(); // Update inventory
        SalesManager.render(); // Update sales dropdown
        this.hideAddForm();
        
        Utils.showMessage('محصول با موفقیت اضافه شد!');
    },

    render: function() {
        const tbody = document.getElementById('admin-products-list');
        tbody.innerHTML = '';
        
        products.forEach((product, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${index + 1}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.code}</td>
                <td class="px-4 py-4 whitespace-nowrap text-center">
                    <img src="${CONFIG.PATHS.PRODUCT_IMAGES}${product.code}.jpg" alt="${product.name}" class="w-12 h-12 object-cover rounded mx-auto" onerror="this.style.display='none'; this.parentElement.innerHTML='<span class=\\'text-gray-400\\'>بدون تصویر</span>';">
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-center">
                    ${product.video ? `<video src="${CONFIG.PATHS.PRODUCT_VIDEOS}${product.code}.mp4" class="w-12 h-12 object-cover rounded mx-auto" controls></video>` : '<span class="text-gray-400">بدون ویدیو</span>'}
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.name}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${Utils.formatPrice(product.price)} افغانی
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${Utils.getCategoryName(product.category)}
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                    ${product.rating} ⭐
                </td>
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                    <div class="flex space-x-2 space-x-reverse">
                        <button onclick="AdminProductManager.edit(${product.id})" class="text-blue-600 hover:text-blue-900">اصلاح</button>
                        <button onclick="AdminProductManager.delete(${product.id})" class="text-red-600 hover:text-red-900">حذف</button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    },

    edit: function(productId) {
        const product = products.find(p => p.id === productId);
        if (!product) return;

        // Show form first
        this.showAddForm();

        // Fill form with product data after showing
        setTimeout(() => {
            document.getElementById('product-code').value = product.code;
            document.getElementById('product-name').value = product.name;
            document.getElementById('product-stock').value = product.stock;
            document.getElementById('product-cost-price').value = product.costPrice;
            document.getElementById('product-original-price').value = product.originalPrice;
            document.getElementById('product-price').value = product.price;
            document.getElementById('product-customer-price').value = product.customerPrice;
            document.getElementById('product-category').value = product.category;
            document.getElementById('product-rating').value = product.rating;
            document.getElementById('product-description').value = product.description;
            document.getElementById('product-ingredients').value = product.ingredients;
            document.getElementById('product-usage').value = product.usage;

            // Change form to edit mode
            const form = document.getElementById('add-product-form').querySelector('form');
            form.onsubmit = (event) => this.update(event, productId);
            
            // Change button text
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.textContent = 'بروزرسانی محصول';
            submitBtn.className = 'bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600';
        }, 100);
    },

    update: function(event, productId) {
        event.preventDefault();
        
        const product = products.find(p => p.id === productId);
        if (!product) return;

        // Update product data
        product.code = document.getElementById('product-code').value;
        product.name = document.getElementById('product-name').value;
        product.stock = parseInt(document.getElementById('product-stock').value);
        product.costPrice = document.getElementById('product-cost-price').value;
        product.originalPrice = document.getElementById('product-original-price').value;
        product.price = document.getElementById('product-price').value;
        product.customerPrice = document.getElementById('product-customer-price').value;
        product.category = document.getElementById('product-category').value;
        product.rating = parseFloat(document.getElementById('product-rating').value);
        product.description = document.getElementById('product-description').value;
        product.ingredients = document.getElementById('product-ingredients').value;
        product.usage = document.getElementById('product-usage').value;

        // Reset form to add mode
        const form = document.getElementById('add-product-form').querySelector('form');
        form.onsubmit = (event) => this.add(event);
        
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'افزودن محصول';
        submitBtn.className = 'bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600';

        this.render();
        ProductManager.render();
        InventoryManager.render();
        SalesManager.render();
        this.hideAddForm();
        
        Utils.showMessage('محصول با موفقیت بروزرسانی شد!');
    },

    delete: function(productId) {
        if (confirm('آیا مطمئن هستید که می‌خواهید این محصول را حذف کنید؟')) {
            products = products.filter(p => p.id !== productId);
            this.render();
            ProductManager.render();
            InventoryManager.render();
            SalesManager.render();
            Utils.showMessage('محصول حذف شد');
        }
    }
};

// ========== EXPENSE MANAGEMENT ==========
const ExpenseManager = {
    showAddForm: function() {
        document.getElementById('add-expense-form').classList.remove('hidden');
    },

    hideAddForm: function() {
        document.getElementById('add-expense-form').classList.add('hidden');
        document.getElementById('add-expense-form').querySelector('form').reset();
    },

    add: function(event) {
        event.preventDefault();
        
        const newExpense = {
            id: expenses.length + 1,
            type: document.getElementById('expense-type').value,
            amount: parseInt(document.getElementById('expense-amount').value),
            description: document.getElementById('expense-description').value,
            date: new Date().toLocaleDateString('en-US'),
            editable: currentAdminRole === 'admin'
        };
        
        expenses.push(newExpense);
        this.render();
        this.hideAddForm();
        FinancialManager.updateStats();
        
        Utils.showMessage('مصرف با موفقیت اضافه شد!');
    },

    render: function() {
        const tbody = document.getElementById('expenses-list');
        tbody.innerHTML = '';
        
        expenses.forEach((expense, index) => {
            const row = document.createElement('tr');
            const canEdit = currentAdminRole === 'admin' && expense.editable;
            
            row.innerHTML = `
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${index + 1}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${this.getExpenseTypeName(expense.type)}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${expense.date}</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${Utils.formatPrice(expense.amount)} افغانی</td>
                <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">${expense.description || '-'}</td>
                ${currentAdminRole === 'admin' ? `
                <td class="px-4 py-4 whitespace-nowrap text-sm font-medium">
                    ${canEdit ? `
                        <div class="flex space-x-2 space-x-reverse">
                            <button onclick="ExpenseManager.edit(${expense.id})" class="text-blue-600 hover:text-blue-900">ویرایش</button>
                            <button onclick="ExpenseManager.delete(${expense.id})" class="text-red-600 hover:text-red-900">حذف</button>
                        </div>
                    ` : '<span class="text-gray-400">غیرقابل ویرایش</span>'}
                </td>
                ` : ''}
            `;
            tbody.appendChild(row);
        });
    },

    edit: function(expenseId) {
        if (currentAdminRole !== 'admin') {
            Utils.showMessage('شما اجازه ویرایش مصارف را ندارید', 'error');
            return;
        }

        const expense = expenses.find(e => e.id === expenseId);
        if (!expense || !expense.editable) {
            Utils.showMessage('این مصرف قابل ویرایش نیست', 'error');
            return;
        }

        // Fill form with expense data
        document.getElementById('expense-type').value = expense.type;
        document.getElementById('expense-amount').value = expense.amount;
        document.getElementById('expense-description').value = expense.description;

        // Change form to edit mode
        const form = document.getElementById('add-expense-form').querySelector('form');
        form.onsubmit = (event) => this.update(event, expenseId);
        
        // Change button text
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'بروزرسانی مصرف';
        submitBtn.className = 'bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600';

        this.showAddForm();
    },

    update: function(event, expenseId) {
        event.preventDefault();
        
        const expense = expenses.find(e => e.id === expenseId);
        if (!expense) return;

        expense.type = document.getElementById('expense-type').value;
        expense.amount = parseInt(document.getElementById('expense-amount').value);
        expense.description = document.getElementById('expense-description').value;

        // Reset form to add mode
        const form = document.getElementById('add-expense-form').querySelector('form');
        form.onsubmit = (event) => this.add(event);
        
        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.textContent = 'افزودن مصرف';
        submitBtn.className = 'bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600';

        this.render();
        this.hideAddForm();
        FinancialManager.updateStats();
        
        Utils.showMessage('مصرف با موفقیت بروزرسانی شد!');
    },

    delete: function(expenseId) {
        if (currentAdminRole !== 'admin') {
            Utils.showMessage('شما اجازه حذف مصارف را ندارید', 'error');
            return;
        }

        if (confirm('آیا مطمئن هستید که می‌خواهید این مصرف را حذف کنید؟')) {
            expenses = expenses.filter(e => e.id !== expenseId);
            this.render();
            FinancialManager.updateStats();
            Utils.showMessage('مصرف حذف شد');
        }
    },

    printExpenses: function(period = 'all') {
        const printWindow = window.open('', '_blank');
        const currentDate = new Date().toLocaleDateString('en-US');
        
        let filteredExpenses = [];
        let periodTitle = '';
        
        const today = new Date().toLocaleDateString('en-US');
        const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        switch(period) {
            case 'today':
                filteredExpenses = expenses.filter(expense => expense.date === today);
                periodTitle = 'مصارف امروز';
                break;
            case 'weekly':
                filteredExpenses = expenses.filter(expense => {
                    const expenseDate = new Date(expense.date);
                    return expenseDate >= oneWeekAgo;
                });
                periodTitle = 'مصارف هفتگی';
                break;
            case 'monthly':
                filteredExpenses = expenses.filter(expense => {
                    const expenseDate = new Date(expense.date);
                    return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
                });
                periodTitle = 'مصارف ماهانه';
                break;
            case 'all':
                filteredExpenses = expenses;
                periodTitle = 'تمام مصارف';
                break;
        }

        let totalExpenses = 0;
        filteredExpenses.forEach(expense => {
            totalExpenses += expense.amount;
        });

        const printContent = `
            <!DOCTYPE html>
            <html dir="rtl" lang="fa">
            <head>
                <meta charset="UTF-8">
                <title>گزارش مصارف - فروشگاه مصطفی ادیب</title>
                <style>
                    @page { size: A4 portrait; margin: 2cm; }
                    body { font-family: 'B Mitra', Arial, sans-serif; font-size: 12px; line-height: 1.4; }
                    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
                    .header h1 { margin: 0; font-size: 18px; }
                    .header p { margin: 5px 0; color: #666; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
                    th { background-color: #f5f5f5; font-weight: bold; }
                    .total-row { background-color: #e8f5e8; font-weight: bold; }
                    .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>گزارش ${periodTitle}</h1>
                    <p>فروشگاه مصطفی ادیب</p>
                    <p>تاریخ چاپ: ${currentDate}</p>
                </div>
                
                <table>
                    <thead>
                        <tr>
                            <th>شماره</th>
                            <th>نوع مصرف</th>
                            <th>تاریخ</th>
                            <th>مبلغ (افغانی)</th>
                            <th>توضیحات</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredExpenses.map((expense, index) => `
                            <tr>
                                <td>${index + 1}</td>
                                <td>${this.getExpenseTypeName(expense.type)}</td>
                                <td>${expense.date}</td>
                                <td>${Utils.formatPrice(expense.amount)}</td>
                                <td>${expense.description || '-'}</td>
                            </tr>
                        `).join('')}
                        <tr class="total-row">
                            <td colspan="3">مجموع کل مصارف</td>
                            <td>${Utils.formatPrice(totalExpenses)}</td>
                            <td>-</td>
                        </tr>
                    </tbody>
                </table>
                
                <div style="margin-top: 50px; display: flex; justify-content: space-between; align-items: flex-end;">
                    <div style="text-align: right; width: 45%;">
                        <div style="border-top: 1px solid #333; padding-top: 10px; margin-top: 40px;">
                            <p style="margin: 0; font-weight: bold;">امضای مدیر فروشات</p>
                        </div>
                    </div>
                    <div style="text-align: left; width: 45%;">
                        <div style="border-top: 1px solid #333; padding-top: 10px; margin-top: 40px;">
                            <p style="margin: 0; font-weight: bold;">امضای مدیر مالی</p>
                        </div>
                    </div>
                </div>
                
                <div class="footer">
                    <p>این گزارش توسط سیستم مدیریت فروشگاه مصطفی ادیب تولید شده است</p>
                    <p>تلفن: 93792149150 | ایمیل: jalaluddinyaqubi@gmail.com</p>
                </div>
            </body>
            </html>
        `;

        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
    },

    getExpenseTypeName: function(type) {
        const types = {
            'rent': 'کرایه',
            'storage': 'انبارداری',
            'marketing': 'بازاریابی',
            'transport': 'حمل و نقل',
            'utilities': 'آب و برق',
            'salary': 'حقوق',
            'other': 'سایر'
        };
        return types[type] || type;
    }
};