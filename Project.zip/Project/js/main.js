document.addEventListener('DOMContentLoaded', function() {
    ProductManager.render();
    ProductSlider.init();
    
    // Load logo if exists
    const logoImg = document.getElementById('site-logo');
    const logoText = document.getElementById('logo-text');
    
    logoImg.src = CONFIG.PATHS.LOGO;
    logoImg.onload = function() {
        logoImg.classList.remove('hidden');
        logoText.style.display = 'none';
    };
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Handle window resize for slider
    window.addEventListener('resize', function() {
        Object.keys(sliderIndices).forEach(category => {
            ProductSlider.updatePosition(category);
        });
    });
});