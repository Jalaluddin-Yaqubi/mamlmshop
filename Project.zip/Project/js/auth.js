const UserAuth = {
    showModal: function() {
        if (currentUser) {
            if (confirm('آیا می‌خواهید خروج کنید؟')) {
                this.logout();
            }
        } else {
            document.getElementById('login-modal').classList.add('active');
        }
    },

    closeModal: function() {
        document.getElementById('login-modal').classList.remove('active');
        this.showLogin();
    },

    showLogin: function() {
        document.getElementById('register-form').classList.add('hidden');
        document.getElementById('forgot-password-form').classList.add('hidden');
        document.getElementById('verification-form').classList.add('hidden');
        document.getElementById('login-form').classList.remove('hidden');
        document.getElementById('modal-title').textContent = 'ورود';
    },

    showRegister: function() {
        document.getElementById('login-form').classList.add('hidden');
        document.getElementById('forgot-password-form').classList.add('hidden');
        document.getElementById('verification-form').classList.add('hidden');
        document.getElementById('register-form').classList.remove('hidden');
        document.getElementById('modal-title').textContent = 'ثبت نام';
    },

    handleLogin: function(event) {
        event.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        const user = users.find(u => u.email === email && u.password === password);
        if (user) {
            if (user.approved) {
                currentUser = user;
                this.closeModal();
                Utils.showMessage(`خوش آمدید ${user.name}!`);
                this.updateButton();
            } else {
                Utils.showMessage('حساب شما هنوز تایید نشده است. لطفاً منتظر تایید مدیر باشید.', 'error');
            }
        } else {
            Utils.showMessage('ایمیل یا رمز عبور اشتباه است', 'error');
        }
    },

    handleRegister: function(event) {
        event.preventDefault();
        const name = document.getElementById('register-name').value;
        const phone = document.getElementById('register-phone').value;
        const whatsapp = document.getElementById('register-whatsapp').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        
        if (users.find(u => u.email === email)) {
            Utils.showMessage('این ایمیل قبلاً ثبت شده است', 'error');
            return;
        }
        
        const newUser = {
            id: users.length + 1,
            name,
            phone,
            whatsapp,
            email,
            password,
            approved: false,
            registrationDate: new Date().toLocaleDateString('en-US')
        };
        
        users.push(newUser);
        
        // Send notification to admin email (simulated)
        setTimeout(() => {
            Utils.showMessage(`درخواست ثبت نام ${name} به ایمیل مدیر (jalaluddinyaqubi@gmail.com) ارسال شد`);
        }, 1000);
        
        this.closeModal();
        Utils.showMessage(`ثبت نام با موفقیت انجام شد! حساب شما پس از تایید مدیر فعال خواهد شد.`);
    },

    updateButton: function() {
        const loginButton = document.getElementById('login-button');
        if (currentUser) {
            loginButton.textContent = `سلام ${currentUser.name}`;
        } else {
            loginButton.textContent = 'ورود / ثبت نام';
        }
    },

    logout: function() {
        currentUser = null;
        this.updateButton();
        Utils.showMessage('با موفقیت خارج شدید');
    }
};

// ========== PASSWORD RESET ==========
const PasswordReset = {
    show: function() {
        document.getElementById('login-form').classList.add('hidden');
        document.getElementById('register-form').classList.add('hidden');
        document.getElementById('verification-form').classList.add('hidden');
        document.getElementById('forgot-password-form').classList.remove('hidden');
        document.getElementById('modal-title').textContent = 'بازیابی رمز عبور';
    },

    requestCode: function(event) {
        event.preventDefault();
        const email = document.getElementById('forgot-email').value;
        
        // Check if user exists
        const user = users.find(u => u.email === email);
        if (!user) {
            Utils.showMessage('کاربری با این ایمیل یافت نشد', 'error');
            return;
        }

        // Generate verification code
        verificationCode = Utils.generateCode();
        resetEmail = email;
        
        // Simulate email sending
        Utils.showMessage(`کد تایید ${verificationCode} به ایمیل شما ارسال شد`);
        
        // Show verification form
        document.getElementById('forgot-password-form').classList.add('hidden');
        document.getElementById('verification-form').classList.remove('hidden');
        document.getElementById('modal-title').textContent = 'تایید کد';
    },

    verifyCode: function(event) {
        event.preventDefault();
        const enteredCode = document.getElementById('verification-code').value;
        const newPassword = document.getElementById('new-password').value;
        
        if (enteredCode !== verificationCode) {
            Utils.showMessage('کد تایید اشتباه است', 'error');
            return;
        }

        // Update user password
        const user = users.find(u => u.email === resetEmail);
        if (user) {
            user.password = newPassword;
            Utils.showMessage('رمز عبور با موفقیت تغییر کرد');
            
            // Send email notification (simulated)
            setTimeout(() => {
                Utils.showMessage(`اطلاعیه: رمز عبور شما تغییر کرد. ایمیل تایید به ${resetEmail} ارسال شد`);
            }, 1000);
            
            UserAuth.closeModal();
        }
    }
};

// ========== ADMIN AUTHENTICATION ==========
const AdminAuth = {
    showLogin: function() {
        document.getElementById('admin-login-modal').classList.add('active');
    },

    closeLogin: function() {
        document.getElementById('admin-login-modal').classList.remove('active');
    },

    login: function(event) {
        event.preventDefault();
        const username = document.getElementById('admin-username').value;
        const password = document.getElementById('admin-password').value;
        
        if (username === adminCredentials.username && password === adminCredentials.password) {
            isAdminLoggedIn = true;
            currentAdminRole = 'admin';
            this.closeLogin();
            AdminPanel.show();
        } else if (username === employeeCredentials.username && password === employeeCredentials.password) {
            isAdminLoggedIn = true;
            currentAdminRole = 'employee';
            this.closeLogin();
            AdminPanel.show();
        } else {
            Utils.showMessage('نام کاربری یا رمز عبور اشتباه است', 'error');
        }
    },

    logout: function() {
        isAdminLoggedIn = false;
        currentAdminRole = 'admin';
        AdminPanel.showMainSite();
    },

    updateCredentials: function(event) {
        event.preventDefault();
        const newUsername = document.getElementById('new-admin-username').value;
        const newPassword = document.getElementById('new-admin-password').value;
        
        if (currentAdminRole === 'admin') {
            adminCredentials.username = newUsername;
            adminCredentials.password = newPassword;
            Utils.showMessage('اطلاعات مدیریت با موفقیت تغییر کرد!');
        } else {
            Utils.showMessage('شما اجازه تغییر اطلاعات مدیریت را ندارید', 'error');
            return;
        }
        
        document.getElementById('new-admin-username').value = '';
        document.getElementById('new-admin-password').value = '';
    }
};